
<div class="form-group">
	<label>Sub Kategori</label>
	<?php echo form_dropdown('id_sub_kategori',$dd_sub_kategori, $id_sub_kategori, 'required class="form-control"');?>
</div>